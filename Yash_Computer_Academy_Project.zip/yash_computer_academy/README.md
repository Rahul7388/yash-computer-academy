# Yash Computer Academy

Hindi + English course-selling website starter built with Streamlit and SQLite.

## 1. Install

Install Python 3.10 or newer and VS Code. Open this project folder in VS Code.

Windows PowerShell:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation, use Command Prompt:

```bat
.venv\Scripts\activate.bat
```

## 2. Start the website

```powershell
streamlit run app.py
```

The browser will open the local website.

## 3. Create the first admin

Set these environment variables BEFORE the first run. Choose your own strong password.
Do not put real passwords in source code or upload them to GitHub.

PowerShell example (only for the current terminal session):

```powershell
$env:ACADEMY_ADMIN_EMAIL="your-admin-email@example.com"
$env:ACADEMY_ADMIN_PASSWORD="Choose-A-Long-Unique-Password"
streamlit run app.py
```

The first admin is created when the database is initialized. Keep `academy.db` private.
If you already started the app without these variables, remove the local `academy.db`
only if it contains no data, then restart with the variables set.

## 4. Add courses

Sign in as admin -> Admin Dashboard -> Add New Course.
Add course title, description, fee, a video URL, and optional PDF notes.
Use a video URL you own or are authorized to share. For YouTube, use a normal video URL.

## 5. Payments (Razorpay)

This starter can create Razorpay Payment Links. A Razorpay account and live/test API
keys are required. Payment account setup, KYC, and any financial agreements must be
handled by an eligible adult/account owner with the provider.

For local testing, set the keys in PowerShell before starting Streamlit:

```powershell
$env:RAZORPAY_KEY_ID="rzp_test_xxxxx"
$env:RAZORPAY_KEY_SECRET="your_test_secret"
streamlit run app.py
```

For deployment, put secrets in Streamlit's Secrets settings, not in app.py or GitHub:

```toml
RAZORPAY_KEY_ID = "rzp_test_xxxxx"
RAZORPAY_KEY_SECRET = "your_test_secret"
```

IMPORTANT: This starter does NOT automatically verify payment callbacks/webhooks.
After checking the successful payment inside the Razorpay Dashboard, the admin enters
the payment reference and confirms the order in Admin Dashboard. Never enroll a student
based only on a screenshot or an unverified claim. Before going live, add and test a
server-side webhook signature verification flow and HTTPS deployment.

## 6. Deploy

You can deploy on Streamlit Community Cloud by connecting a GitHub repository and
selecting `app.py` as the main file. Add payment keys using the app's Secrets settings.
Do not upload `academy.db`, `.env`, API keys, passwords, or private student data to GitHub.

Important: Streamlit Community Cloud's local filesystem may not be durable for a
production school. Use managed PostgreSQL/object storage for a real multi-user business.
Keep backups and have a privacy policy, terms, refund policy, and support contact.

## Current starter limitations

- SQLite is for learning/prototyping, not a high-traffic production database.
- Admin confirms payments manually after checking the provider dashboard.
- Certificates are basic completion certificates, not accredited qualifications.
- Course completion currently uses a student button; add lesson tracking/quizzes before
  relying on it for formal completion.
- Add rate limiting, email verification, password reset, audit logs, backups, and
  server-side payment webhooks before public production use.
