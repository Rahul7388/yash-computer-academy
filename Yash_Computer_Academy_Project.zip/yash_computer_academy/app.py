import os
import re
import hmac
import hashlib
import secrets
import sqlite3
from datetime import datetime
from pathlib import Path
from io import BytesIO

import streamlit as st

APP_DIR = Path(__file__).parent
DB_PATH = APP_DIR / "academy.db"
UPLOAD_DIR = APP_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

st.set_page_config(page_title="Yash Computer Academy", page_icon="🎓", layout="wide")

# ---------- Database ----------
def db():
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            salt TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'student',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL DEFAULT 0,
            video_url TEXT,
            pdf_path TEXT,
            published INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            course_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            payment_link TEXT,
            payment_reference TEXT,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(course_id) REFERENCES courses(id)
        );
        CREATE TABLE IF NOT EXISTS enrollments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            course_id INTEGER NOT NULL,
            enrolled_at TEXT NOT NULL,
            UNIQUE(user_id, course_id)
        );
        CREATE TABLE IF NOT EXISTS completions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            course_id INTEGER NOT NULL,
            completed_at TEXT NOT NULL,
            UNIQUE(user_id, course_id)
        );
        """)
        # Optional first admin, configured only through environment variables.
        admin_email = os.getenv("ACADEMY_ADMIN_EMAIL", "").strip().lower()
        admin_password = os.getenv("ACADEMY_ADMIN_PASSWORD", "")
        if admin_email and admin_password and not con.execute(
            "SELECT 1 FROM users WHERE email=?", (admin_email,)
        ).fetchone():
            salt, pw_hash = hash_password(admin_password)
            con.execute(
                "INSERT INTO users(name,email,password_hash,salt,role,created_at) VALUES(?,?,?,?,?,?)",
                ("Academy Admin", admin_email, pw_hash, salt, "admin", now())
            )

def now():
    return datetime.utcnow().isoformat(timespec="seconds") + "Z"

# ---------- Password security ----------
def hash_password(password, salt_hex=None):
    salt = bytes.fromhex(salt_hex) if salt_hex else secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1)
    return salt.hex(), digest.hex()

def verify_password(password, salt_hex, expected_hash):
    _, actual = hash_password(password, salt_hex)
    return hmac.compare_digest(actual, expected_hash)

def current_user():
    uid = st.session_state.get("user_id")
    if not uid:
        return None
    with db() as con:
        return con.execute("SELECT id,name,email,role FROM users WHERE id=?", (uid,)).fetchone()

def register_user(name, email, password):
    salt, pw_hash = hash_password(password)
    with db() as con:
        con.execute(
            "INSERT INTO users(name,email,password_hash,salt,role,created_at) VALUES(?,?,?,?,?,?)",
            (name.strip(), email.strip().lower(), pw_hash, salt, "student", now())
        )

def login_user(email, password):
    with db() as con:
        row = con.execute("SELECT * FROM users WHERE email=?", (email.strip().lower(),)).fetchone()
    if row and verify_password(password, row["salt"], row["password_hash"]):
        st.session_state.user_id = row["id"]
        return True
    return False

# ---------- Data helpers ----------
def get_courses(published_only=True):
    sql = "SELECT * FROM courses"
    if published_only:
        sql += " WHERE published=1"
    sql += " ORDER BY id DESC"
    with db() as con:
        return con.execute(sql).fetchall()

def is_enrolled(user_id, course_id):
    with db() as con:
        return con.execute(
            "SELECT 1 FROM enrollments WHERE user_id=? AND course_id=?",
            (user_id, course_id)
        ).fetchone() is not None

def create_order(user_id, course):
    with db() as con:
        cur = con.execute(
            "INSERT INTO orders(user_id,course_id,amount,status,created_at) VALUES(?,?,?,?,?)",
            (user_id, course["id"], course["price"], "pending", now())
        )
        return cur.lastrowid

def make_payment_link(order_id, course_title, amount, customer_email):
    """Creates a Razorpay Payment Link when credentials are configured."""
    try:
        key_id = st.secrets.get("RAZORPAY_KEY_ID", os.getenv("RAZORPAY_KEY_ID", ""))
        key_secret = st.secrets.get("RAZORPAY_KEY_SECRET", os.getenv("RAZORPAY_KEY_SECRET", ""))
    except Exception:
        key_id = os.getenv("RAZORPAY_KEY_ID", "")
        key_secret = os.getenv("RAZORPAY_KEY_SECRET", "")
    if not key_id or not key_secret:
        return None, "Razorpay keys are not configured."
    try:
        import razorpay
        client = razorpay.Client(auth=(key_id, key_secret))
        link = client.payment_link.create({
            "amount": int(round(float(amount) * 100)),
            "currency": "INR",
            "accept_partial": False,
            "description": f"{course_title} - Order #{order_id}",
            "customer": {"email": customer_email},
            "reference_id": f"YCA-{order_id}",
            "notify": {"email": True, "sms": False},
            "reminder_enable": True
        })
        with db() as con:
            con.execute("UPDATE orders SET payment_link=? WHERE id=?", (link["short_url"], order_id))
        return link["short_url"], None
    except Exception as exc:
        return None, f"Payment link create nahi hua: {exc}"

def issue_certificate(user, course):
    from reportlab.lib.pagesizes import landscape, A4
    from reportlab.pdfgen import canvas
    buffer = BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=landscape(A4))
    width, height = landscape(A4)
    pdf.setTitle("Course Completion Certificate")
    pdf.setStrokeColorRGB(0.12, 0.28, 0.48)
    pdf.setLineWidth(5)
    pdf.rect(25, 25, width-50, height-50)
    pdf.setFont("Helvetica-Bold", 28)
    pdf.drawCentredString(width/2, height-115, "CERTIFICATE OF COMPLETION")
    pdf.setFont("Helvetica", 15)
    pdf.drawCentredString(width/2, height-165, "Yash Computer Academy")
    pdf.drawCentredString(width/2, height-220, "This is to certify that")
    pdf.setFont("Helvetica-Bold", 24)
    pdf.drawCentredString(width/2, height-265, user["name"])
    pdf.setFont("Helvetica", 15)
    pdf.drawCentredString(width/2, height-310, "has successfully completed the course")
    pdf.setFont("Helvetica-Bold", 20)
    pdf.drawCentredString(width/2, height-345, course["title"])
    pdf.setFont("Helvetica", 11)
    pdf.drawCentredString(width/2, 85, f"Issued: {datetime.now().strftime('%d %B %Y')}  |  Certificate ID: YCA-{user['id']}-{course['id']}")
    pdf.save()
    buffer.seek(0)
    return buffer.getvalue()

init_db()
st.markdown("""
<style>
.main {background: #f7f9fc;}
.hero {padding: 24px; border-radius: 16px; background: linear-gradient(120deg,#102a43,#2563a6); color:white;}
.small-muted {color:#64748b;}
div[data-testid="stMetric"] {background:white;padding:14px;border-radius:12px;border:1px solid #e5eaf1;}
</style>
""", unsafe_allow_html=True)

# ---------- Sidebar / Navigation ----------
user = current_user()
with st.sidebar:
    st.title("🎓 Yash Computer Academy")
    st.caption("Learn in Hindi & English")
    if user:
        st.success(f"Welcome, {user['name']}")
        page_options = ["Home", "My Courses", "Certificates"]
        if user["role"] == "admin":
            page_options += ["Admin Dashboard"]
        page = st.radio("Menu", page_options)
        if st.button("Logout", use_container_width=True):
            st.session_state.pop("user_id", None)
            st.rerun()
    else:
        page = st.radio("Menu", ["Home", "Login", "Register"])

# ---------- Home ----------
if page == "Home":
    st.markdown('<div class="hero"><h1>Yash Computer Academy</h1><h3>सीखें अपनी भाषा में • Learn Computer Skills Online</h3><p>Computer | Typing | MS Office | Tally ERP 9 | Tally Prime</p></div>', unsafe_allow_html=True)
    st.write("")
    st.subheader("हमारे Courses / Our Courses")
    courses = get_courses()
    if not courses:
        st.info("अभी courses add नहीं किए गए हैं। Admin Dashboard से पहला course जोड़ें।")
    cols = st.columns(2)
    for i, course in enumerate(courses):
        with cols[i % 2]:
            with st.container(border=True):
                st.subheader(course["title"])
                st.write(course["description"] or "Course details coming soon.")
                st.write(f"**Fee: ₹{course['price']:.0f}**" if course["price"] else "**Free Course**")
                if st.button("View Course", key=f"view_{course['id']}"):
                    st.session_state["selected_course"] = course["id"]
                    st.session_state["go_course"] = True
                    st.rerun()
    if st.session_state.get("go_course"):
        st.session_state["go_course"] = False
        st.info("Course देखने के लिए Login करें और My Courses में जाएँ।")

# ---------- Login ----------
elif page == "Login":
    st.title("Student Login / विद्यार्थी लॉगिन")
    with st.form("login_form"):
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Login")
    if submitted:
        if login_user(email, password):
            st.success("Login successful!")
            st.rerun()
        else:
            st.error("Email या password सही नहीं है।")

# ---------- Register ----------
elif page == "Register":
    st.title("Create Student Account / नया अकाउंट")
    with st.form("register_form"):
        name = st.text_input("पूरा नाम / Full name")
        email = st.text_input("Email")
        password = st.text_input("Password (कम से कम 8 characters)", type="password")
        confirm = st.text_input("Confirm password", type="password")
        submitted = st.form_submit_button("Create Account")
    if submitted:
        if not name.strip() or not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email.strip()):
            st.error("कृपया सही नाम और email भरें।")
        elif len(password) < 8:
            st.error("Password कम से कम 8 characters का होना चाहिए।")
        elif password != confirm:
            st.error("दोनों passwords match नहीं करते।")
        else:
            try:
                register_user(name, email, password)
                st.success("Account बन गया। अब Login करें।")
            except sqlite3.IntegrityError:
                st.error("यह email पहले से registered है।")

# ---------- Student pages ----------
elif page == "My Courses":
    if not user:
        st.warning("पहले Login करें।")
    else:
        st.title("My Courses / मेरे कोर्स")
        courses = get_courses()
        enrolled_ids = []
        with db() as con:
            enrolled_ids = [r["course_id"] for r in con.execute(
                "SELECT course_id FROM enrollments WHERE user_id=?", (user["id"],)
            ).fetchall()]
        st.subheader("Available Courses")
        for course in courses:
            with st.container(border=True):
                st.subheader(course["title"])
                st.write(course["description"] or "")
                if course["id"] in enrolled_ids:
                    st.success("आप इस course में enrolled हैं।")
                    if course["video_url"]:
                        st.video(course["video_url"])
                    else:
                        st.info("इस course का video अभी upload नहीं हुआ है।")
                    if course["pdf_path"] and Path(course["pdf_path"]).exists():
                        with open(course["pdf_path"], "rb") as f:
                            st.download_button("Download PDF Notes", f.read(),
                                               file_name=Path(course["pdf_path"]).name,
                                               key=f"pdf_{course['id']}")
                    if st.button("Mark Course Completed", key=f"complete_{course['id']}"):
                        with db() as con:
                            con.execute(
                                "INSERT OR IGNORE INTO completions(user_id,course_id,completed_at) VALUES(?,?,?)",
                                (user["id"], course["id"], now())
                            )
                        st.success("Completion saved. Certificates tab में certificate मिलेगा।")
                else:
                    st.write(f"Fee: ₹{course['price']:.0f}" if course["price"] else "Free")
                    if course["price"] <= 0:
                        if st.button("Enroll Free", key=f"free_{course['id']}"):
                            with db() as con:
                                con.execute(
                                    "INSERT OR IGNORE INTO enrollments(user_id,course_id,enrolled_at) VALUES(?,?,?)",
                                    (user["id"], course["id"], now())
                                )
                            st.success("आप enroll हो गए हैं।")
                            st.rerun()
                    else:
                        if st.button("Buy Course", key=f"buy_{course['id']}"):
                            oid = create_order(user["id"], course)
                            url, error = make_payment_link(oid, course["title"], course["price"], user["email"])
                            if url:
                                st.session_state["last_payment_url"] = url
                                st.session_state["last_order_id"] = oid
                            else:
                                st.warning("Payment link अभी उपलब्ध नहीं है। Admin से संपर्क करें।")
                                st.caption(error)
                        if st.session_state.get("last_payment_url"):
                            st.link_button("Pay securely / भुगतान करें", st.session_state["last_payment_url"])
                            st.caption(f"Order #{st.session_state.get('last_order_id')} — payment confirmation admin द्वारा verify होगी।")

elif page == "Certificates":
    if not user:
        st.warning("पहले Login करें।")
    else:
        st.title("My Certificates / मेरे प्रमाणपत्र")
        with db() as con:
            rows = con.execute("""
                SELECT c.* FROM completions x
                JOIN courses c ON c.id=x.course_id
                WHERE x.user_id=? ORDER BY x.completed_at DESC
            """, (user["id"],)).fetchall()
        if not rows:
            st.info("अभी कोई course complete नहीं हुआ है।")
        for course in rows:
            st.write(f"**{course['title']}**")
            st.download_button(
                "Download Certificate PDF",
                issue_certificate(user, course),
                file_name=f"YCA_Certificate_{course['id']}.pdf",
                mime="application/pdf",
                key=f"cert_{course['id']}"
            )

# ---------- Admin ----------
elif page == "Admin Dashboard":
    if not user or user["role"] != "admin":
        st.error("यह पेज केवल admin के लिए है।")
    else:
        st.title("Admin Dashboard / व्यवस्थापक")
        with db() as con:
            total_users = con.execute("SELECT COUNT(*) n FROM users WHERE role='student'").fetchone()["n"]
            total_courses = con.execute("SELECT COUNT(*) n FROM courses").fetchone()["n"]
            pending = con.execute("SELECT COUNT(*) n FROM orders WHERE status='pending'").fetchone()["n"]
        a,b,c = st.columns(3)
        a.metric("Students", total_users)
        b.metric("Courses", total_courses)
        c.metric("Pending Orders", pending)

        st.subheader("Add New Course")
        with st.form("add_course", clear_on_submit=True):
            title = st.text_input("Course title")
            description = st.text_area("Course description")
            price = st.number_input("Price (₹)", min_value=0.0, step=50.0)
            video_url = st.text_input("Video URL (YouTube or direct video URL)")
            pdf_file = st.file_uploader("PDF Notes (optional)", type=["pdf"])
            published = st.checkbox("Publish course", value=True)
            add = st.form_submit_button("Add Course")
        if add:
            if not title.strip():
                st.error("Course title जरूरी है।")
            else:
                pdf_path = None
                if pdf_file:
                    safe_name = re.sub(r"[^a-zA-Z0-9_-]", "_", title)[:50]
                    dest = UPLOAD_DIR / f"{safe_name}_{secrets.token_hex(4)}.pdf"
                    dest.write_bytes(pdf_file.getvalue())
                    pdf_path = str(dest)
                with db() as con:
                    con.execute(
                        "INSERT INTO courses(title,description,price,video_url,pdf_path,published,created_at) VALUES(?,?,?,?,?,?,?)",
                        (title.strip(), description, float(price), video_url.strip(), pdf_path, int(published), now())
                    )
                st.success("Course added!")
                st.rerun()

        st.subheader("Payment Orders")
        with db() as con:
            orders = con.execute("""
                SELECT o.*, u.name, u.email, c.title
                FROM orders o JOIN users u ON u.id=o.user_id
                JOIN courses c ON c.id=o.course_id ORDER BY o.id DESC
            """).fetchall()
        if not orders:
            st.info("अभी कोई order नहीं है।")
        for order in orders:
            with st.container(border=True):
                st.write(f"**Order #{order['id']} — {order['title']} — ₹{order['amount']:.0f}**")
                st.caption(f"{order['name']} ({order['email']}) | Status: {order['status']}")
                if order["payment_link"]:
                    st.write(order["payment_link"])
                if order["status"] == "pending":
                    ref = st.text_input("Payment reference / Razorpay payment ID",
                                        key=f"ref_{order['id']}")
                    if st.button("Confirm payment & Enroll student", key=f"confirm_{order['id']}"):
                        if not ref.strip():
                            st.error("पहले Razorpay Dashboard में payment verify करके reference भरें।")
                        else:
                            with db() as con:
                                con.execute(
                                    "UPDATE orders SET status='paid', payment_reference=? WHERE id=?",
                                    (ref.strip(), order["id"])
                                )
                                con.execute(
                                    "INSERT OR IGNORE INTO enrollments(user_id,course_id,enrolled_at) VALUES(?,?,?)",
                                    (order["user_id"], order["course_id"], now())
                                )
                            st.success("Payment marked paid and student enrolled.")
                            st.rerun()

        st.subheader("Existing Courses")
        for course in get_courses(published_only=False):
            st.write(f"#{course['id']} — {course['title']} — ₹{course['price']:.0f} — {'Published' if course['published'] else 'Hidden'}")
            col1, col2 = st.columns(2)
            with col1:
                if st.button("Hide / Publish", key=f"toggle_{course['id']}"):
                    with db() as con:
                        con.execute("UPDATE courses SET published=1-published WHERE id=?", (course["id"],))
                    st.rerun()
            with col2:
                if st.button("Delete course", key=f"delete_{course['id']}"):
                    with db() as con:
                        con.execute("DELETE FROM courses WHERE id=?", (course["id"],))
                    st.rerun()

st.sidebar.divider()
st.sidebar.caption("© Yash Computer Academy")
